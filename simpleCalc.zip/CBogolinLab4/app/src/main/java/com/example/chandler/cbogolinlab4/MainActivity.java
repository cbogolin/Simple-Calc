package com.example.chandler.cbogolinlab4;

import android.app.Activity;
import android.content.Context;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.view.View.OnKeyListener;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    WebView wv;
    EditText url;

    //Spinner stuff
    Spinner spinner;
    ArrayAdapter<CharSequence> adapter;
    String spinnerItem;

    //File I/O
        File sdCard;
        File directory;
        File file;
        FileOutputStream fos;
        OutputStreamWriter osw;


    List<String> favoritesArray;

    //back as back button
    @Override
    public void onBackPressed()
    {
        if (wv.canGoBack())
        {
            wv.goBack();
        }
        else
        {
            super.onBackPressed();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        wv = (WebView)findViewById(R.id.wv);
        url = (EditText)findViewById(R.id.editText);
        favoritesArray = new ArrayList<>();
        url.setOnKeyListener(new OnKeyListener()
        {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event)
            {
                if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER))
                {
                    String s =  "http://" + url.getText().toString();
                    wv.loadUrl(s);
                    return true;
                }
                else
                {
                    return false;
                }
            }
        });

        //Enable JavaScript
        wv.getSettings().setJavaScriptEnabled(true);
        wv.setFocusable(true);
        wv.setFocusableInTouchMode(true);

        //Set render priority to High
        wv.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
        wv.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        wv.getSettings().setDomStorageEnabled(true);
        wv.getSettings().setDatabaseEnabled(true);
        wv.getSettings().setAppCacheEnabled(true);
        wv.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);

        //Load URL
        wv.loadUrl("https://www.kennesaw.edu/");
        wv.setWebViewClient(new WebViewClient());



        //File I/O stuff
        try
        {
            sdCard = Environment.getExternalStorageDirectory();
            directory = new File(sdCard.getAbsolutePath()+"/MyFiles");
            directory.mkdirs();
            file = new File(directory, "fave.txt");
            fos = new FileOutputStream(file, true);
            osw = new OutputStreamWriter(fos);
        } catch (IOException e)
        {
            e.printStackTrace();
        }

        favoritesArray = readFavorites();
        //favoritesArray.add("end");

        //Spinner stuff found from https://developer.android.com/guide/topics/ui/controls/spinner.html
        spinner = (Spinner)findViewById(R.id.spinner2);
        ArrayAdapter<String> listAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, favoritesArray);
        listAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        listAdapter.notifyDataSetChanged();
        spinner.setAdapter(listAdapter);

        //more voodoo magic
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                //Toast.makeText(getBaseContext(),parent.getItemAtPosition(position) + " selected", Toast.LENGTH_LONG).show();
                spinnerItem = parent.getItemAtPosition(position).toString();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });




    }

    public void navigate(View view)
    {
        String s = "http://" + url.getText().toString();
        wv.loadUrl(s);
    }

    public void loadFavorite (View view)
    {
        url.setText(spinnerItem);
        wv.loadUrl("http://" + spinnerItem);
    }

    public List<String> readFavorites ()
    {
        String line = "";
        List<String> favoritesList = new ArrayList<>();
        try
        {
            FileInputStream fis = new FileInputStream(file);
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis, Charset.forName("UTF-8")));
            while((line = reader.readLine()) != null)
            {
                favoritesList.add(line);
            }
            fis.close();
        } catch (IOException e)
        {
            Log.wtf("MyApp","Error reading data file on line " + line, e);
            e.printStackTrace();
        }
        return favoritesList;

    }

    public void saveFavorite (View view)
    {
        favoritesArray.add(url.getText().toString());
        try
        {
            osw.append(url.getText());
            osw.append('\n');
            osw.flush();
            //osw.close();
            Toast.makeText(this,"Text Saved",Toast.LENGTH_LONG).show();

        } catch (IOException e)
        {
            Toast.makeText(this, "Text Could not be added",Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

}
